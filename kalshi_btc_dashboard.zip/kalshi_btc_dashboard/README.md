# Kalshi BTC 15-Minute Paper Trading Dashboard

## Run locally

1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. `python -m pip install -r requirements.txt`
4. `python -m streamlit run app.py`
5. Open the local URL Streamlit prints (typically http://localhost:8501).

The app polls public Kalshi `KXBTC15M` market data every five seconds while open, rotates to the nearest open market, charts observed YES contract-price snapshots, provides simple momentum WATCH indicators, and lets you buy/sell simulated contracts. Paper records persist in `paper_trades.db` in this folder. No Kalshi login or API key is required for market quotes. No real orders are sent.

## Important limitations

- The price chart is Kalshi contract prices, not a Bitcoin spot/index chart. It builds only from samples observed while running.
- The WATCH indicators are not predictive signals, and there is no demonstrated edge or backtest.
- Paper fills assume the quoted ask for entry and bid for exit. Real fills may differ.
- Fees and slippage are excluded from reported P/L.
- Automatic settlement runs only while the app is open and can fetch the market result.
- Data access and field formats can change. If Kalshi requires authentication for an endpoint, the app will report an API error.
- Alerts are on-screen only. No push notifications, auto execution, or background server included.
- Paper bankroll is for display and a simple cash-spend guard; it is not a full accounting ledger.
